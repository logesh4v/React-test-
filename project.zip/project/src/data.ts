import { Restaurant, MenuItem } from './types';

export const restaurants: Restaurant[] = [
  {
    id: '1',
    name: 'Burger Palace',
    image: 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=500',
    cuisine: 'American',
    rating: 4.5,
    deliveryTime: '25-35 min',
    minimumOrder: 15,
  },
  {
    id: '2',
    name: 'Pizza Heaven',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500',
    cuisine: 'Italian',
    rating: 4.7,
    deliveryTime: '30-40 min',
    minimumOrder: 20,
  },
  {
    id: '3',
    name: 'Sushi Master',
    image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=500',
    cuisine: 'Japanese',
    rating: 4.8,
    deliveryTime: '35-45 min',
    minimumOrder: 25,
  },
];

export const menuItems: MenuItem[] = [
  {
    id: '1',
    restaurantId: '1',
    name: 'Classic Burger',
    description: 'Juicy beef patty with lettuce, tomato, and special sauce',
    price: 12.99,
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500',
  },
  {
    id: '2',
    restaurantId: '1',
    name: 'Cheese Fries',
    description: 'Crispy fries topped with melted cheese',
    price: 6.99,
    image: 'https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?w=500',
  },
  {
    id: '3',
    restaurantId: '2',
    name: 'Margherita Pizza',
    description: 'Fresh tomatoes, mozzarella, and basil',
    price: 16.99,
    image: 'https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?w=500',
  },
  {
    id: '4',
    restaurantId: '3',
    name: 'California Roll',
    description: 'Crab, avocado, and cucumber',
    price: 14.99,
    image: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=500',
  },
];