import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Order, Restaurant } from '../types';
import { Package, Clock, CheckCircle, XCircle } from 'lucide-react';

export const AdminConsole: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);

  useEffect(() => {
    loadOrders();
    loadRestaurants();
  }, []);

  const loadOrders = async () => {
    const { data } = await supabase
      .from('orders')
      .select('*')
      .order('createdAt', { ascending: false });
    if (data) setOrders(data);
  };

  const loadRestaurants = async () => {
    const { data } = await supabase
      .from('restaurants')
      .select('*');
    if (data) setRestaurants(data);
  };

  const updateOrderStatus = async (orderId: string, status: Order['status']) => {
    const { error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', orderId);
    
    if (!error) {
      setOrders(orders.map(order =>
        order.id === orderId ? { ...order, status } : order
      ));
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-8">
      <h2 className="text-2xl font-bold mb-6">Admin Console</h2>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h3 className="text-xl font-semibold mb-4">Recent Orders</h3>
        <div className="space-y-4">
          {orders.map(order => {
            const restaurant = restaurants.find(r => r.id === order.restaurantId);
            return (
              <div key={order.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h4 className="font-semibold">{restaurant?.name}</h4>
                    <p className="text-sm text-gray-600">
                      Order #{order.id.slice(0, 8)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      value={order.status}
                      onChange={(e) => updateOrderStatus(order.id, e.target.value as Order['status'])}
                      className="border rounded p-2"
                    >
                      <option value="pending">Pending</option>
                      <option value="confirmed">Confirmed</option>
                      <option value="preparing">Preparing</option>
                      <option value="delivering">Delivering</option>
                      <option value="delivered">Delivered</option>
                    </select>
                  </div>
                </div>
                <div className="mt-2">
                  <p className="text-sm text-gray-600">
                    Items: {order.items.reduce((sum, item) => sum + item.quantity, 0)}
                  </p>
                  <p className="font-semibold">
                    Total: ${order.total.toFixed(2)}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-green-100 rounded-lg p-6">
          <Package className="w-8 h-8 text-green-600 mb-2" />
          <h4 className="font-semibold">Total Orders</h4>
          <p className="text-2xl font-bold">{orders.length}</p>
        </div>
        <div className="bg-yellow-100 rounded-lg p-6">
          <Clock className="w-8 h-8 text-yellow-600 mb-2" />
          <h4 className="font-semibold">Pending Orders</h4>
          <p className="text-2xl font-bold">
            {orders.filter(o => o.status === 'pending').length}
          </p>
        </div>
        <div className="bg-blue-100 rounded-lg p-6">
          <CheckCircle className="w-8 h-8 text-blue-600 mb-2" />
          <h4 className="font-semibold">Completed Orders</h4>
          <p className="text-2xl font-bold">
            {orders.filter(o => o.status === 'delivered').length}
          </p>
        </div>
        <div className="bg-purple-100 rounded-lg p-6">
          <XCircle className="w-8 h-8 text-purple-600 mb-2" />
          <h4 className="font-semibold">Active Restaurants</h4>
          <p className="text-2xl font-bold">{restaurants.length}</p>
        </div>
      </div>
    </div>
  );
};