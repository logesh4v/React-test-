import React from 'react';
import { MenuItem as MenuItemType } from '../types';
import { Plus } from 'lucide-react';

interface Props {
  item: MenuItemType;
  onAddToCart: (item: MenuItemType) => void;
}

export const MenuItem: React.FC<Props> = ({ item, onAddToCart }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 flex gap-4">
      <img 
        src={item.image} 
        alt={item.name} 
        className="w-24 h-24 object-cover rounded-lg"
      />
      <div className="flex-1">
        <h3 className="text-lg font-semibold">{item.name}</h3>
        <p className="text-gray-600 text-sm">{item.description}</p>
        <div className="flex items-center justify-between mt-2">
          <span className="font-semibold">${item.price.toFixed(2)}</span>
          <button
            onClick={() => onAddToCart(item)}
            className="bg-green-500 text-white p-2 rounded-full hover:bg-green-600 transition-colors"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};