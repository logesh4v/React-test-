import React from 'react';
import { Star, Heart } from 'lucide-react';
import { Restaurant } from '../types';

interface Props {
  restaurant: Restaurant;
  onClick: (id: string) => void;
  isFavorite?: boolean;
  onFavoriteClick?: (id: string) => void;
}

export const RestaurantCard: React.FC<Props> = ({
  restaurant,
  onClick,
  isFavorite,
  onFavoriteClick
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden cursor-pointer transform transition-transform hover:scale-105">
      <div className="relative">
        <img 
          src={restaurant.image} 
          alt={restaurant.name} 
          className="w-full h-48 object-cover"
        />
        {onFavoriteClick && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onFavoriteClick(restaurant.id);
            }}
            className={`absolute top-2 right-2 p-2 rounded-full bg-white shadow-md ${
              isFavorite ? 'text-red-500' : 'text-gray-400'
            }`}
          >
            <Heart className="w-6 h-6 fill-current" />
          </button>
        )}
      </div>
      <div
        className="p-4"
        onClick={() => onClick(restaurant.id)}
      >
        <h3 className="text-xl font-semibold">{restaurant.name}</h3>
        <p className="text-gray-600">{restaurant.cuisine}</p>
        <div className="flex items-center mt-2">
          <Star className="w-5 h-5 text-yellow-400 fill-current" />
          <span className="ml-1">{restaurant.rating}</span>
          <span className="mx-2">•</span>
          <span>{restaurant.deliveryTime}</span>
        </div>
        <p className="text-sm text-gray-500 mt-1">
          Minimum order: ${restaurant.minimumOrder}
        </p>
      </div>
    </div>
  );
};