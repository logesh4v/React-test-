import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from 'react-router-dom';
import { Restaurant, MenuItem as MenuItemType, CartItem, User } from './types';
import { restaurants, menuItems } from './data';
import { RestaurantCard } from './components/RestaurantCard';
import { MenuItem } from './components/MenuItem';
import { Cart } from './components/Cart';
import { AuthForm } from './components/AuthForm';
import { UserProfile } from './components/UserProfile';
import { AdminConsole } from './components/AdminConsole';
import { ChevronLeft, User as UserIcon, LogOut, Heart } from 'lucide-react';
import { supabase } from './lib/supabase';

function App() {
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [user, setUser] = useState<User | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        loadUserProfile(session.user.id);
        loadFavorites(session.user.id);
      }
    });

    supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        loadUserProfile(session.user.id);
        loadFavorites(session.user.id);
      } else {
        setUser(null);
        setFavorites([]);
      }
    });
  }, []);

  const loadUserProfile = async (userId: string) => {
    const { data } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
    if (data) setUser(data);
  };

  const loadFavorites = async (userId: string) => {
    const { data } = await supabase
      .from('favorites')
      .select('restaurant_id')
      .eq('user_id', userId);
    if (data) setFavorites(data.map(f => f.restaurant_id));
  };

  const handleRestaurantClick = (id: string) => {
    const restaurant = restaurants.find(r => r.id === id);
    if (restaurant) setSelectedRestaurant(restaurant);
  };

  const handleAddToCart = (item: MenuItemType) => {
    setCartItems(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (id: string, quantity: number) => {
    setCartItems(prev =>
      prev.map(item =>
        item.id === id ? { ...item, quantity } : item
      ).filter(item => item.quantity > 0)
    );
  };

  const handleRemoveFromCart = (id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const toggleFavorite = async (restaurantId: string) => {
    if (!user) return;

    const isFavorite = favorites.includes(restaurantId);
    if (isFavorite) {
      await supabase
        .from('favorites')
        .delete()
        .eq('user_id', user.id)
        .eq('restaurant_id', restaurantId);
      setFavorites(prev => prev.filter(id => id !== restaurantId));
    } else {
      await supabase
        .from('favorites')
        .insert({ user_id: user.id, restaurant_id: restaurantId });
      setFavorites(prev => [...prev, restaurantId]);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <nav className="bg-white shadow-md">
          <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <Link to="/" className="text-xl font-bold text-green-600">
             YUMCART
            </Link>
            <div className="flex items-center gap-4">
              {user ? (
                <>
                  <Link to="/profile" className="flex items-center gap-2 text-gray-600 hover:text-gray-900">
                    <UserIcon className="w-5 h-5" />
                    <span>{user.name || 'Profile'}</span>
                  </Link>
                  {user.role === 'admin' && (
                    <Link to="/admin" className="text-gray-600 hover:text-gray-900">
                      Admin Console
                    </Link>
                  )}
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
                  >
                    <LogOut className="w-5 h-5" />
                    <span>Logout</span>
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login" className="text-gray-600 hover:text-gray-900">Login</Link>
                  <Link to="/register" className="text-gray-600 hover:text-gray-900">Register</Link>
                </>
              )}
            </div>
          </div>
        </nav>

        <div className="max-w-7xl mx-auto px-4 py-8">
          <Routes>
            <Route path="/login" element={
              user ? <Navigate to="/" /> : <AuthForm mode="login" />
            } />
            <Route path="/register" element={
              user ? <Navigate to="/" /> : <AuthForm mode="register" />
            } />
            <Route path="/profile" element={
              user ? <UserProfile /> : <Navigate to="/login" />
            } />
            <Route path="/admin" element={
              user?.role === 'admin' ? <AdminConsole /> : <Navigate to="/" />
            } />
            <Route path="/" element={
              selectedRestaurant ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="md:col-span-2">
                    <button
                      onClick={() => setSelectedRestaurant(null)}
                      className="flex items-center text-gray-600 mb-4 hover:text-gray-900"
                    >
                      <ChevronLeft className="w-5 h-5" />
                      <span>Back to restaurants</span>
                    </button>
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-2xl font-bold">{selectedRestaurant.name}</h2>
                      {user && (
                        <button
                          onClick={() => toggleFavorite(selectedRestaurant.id)}
                          className={`p-2 rounded-full ${
                            favorites.includes(selectedRestaurant.id)
                              ? 'text-red-500'
                              : 'text-gray-400'
                          }`}
                        >
                          <Heart className="w-6 h-6 fill-current" />
                        </button>
                      )}
                    </div>
                    <div className="space-y-4">
                      {menuItems
                        .filter(item => item.restaurantId === selectedRestaurant.id)
                        .map(item => (
                          <MenuItem
                            key={item.id}
                            item={item}
                            onAddToCart={handleAddToCart}
                          />
                        ))}
                    </div>
                  </div>
                  <div className="md:col-span-1">
                    <Cart
                      items={cartItems}
                      onUpdateQuantity={handleUpdateQuantity}
                      onRemove={handleRemoveFromCart}
                    />
                  </div>
                </div>
              ) : (
                <>
                  <h1 className="text-3xl font-bold mb-8">Food Delivery</h1>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {restaurants.map(restaurant => (
                      <RestaurantCard
                        key={restaurant.id}
                        restaurant={restaurant}
                        onClick={handleRestaurantClick}
                        isFavorite={favorites.includes(restaurant.id)}
                        onFavoriteClick={user ? toggleFavorite : undefined}
                      />
                    ))}
                  </div>
                </>
              )
            } />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;