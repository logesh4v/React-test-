import React, { useState } from 'react';
import { ShoppingBag, Search, User, Home, Clock, Star, Pizza, Sandwich, Beef, Utensils, Coffee, IceCream } from 'lucide-react';

interface Restaurant {
  id: number;
  name: string;
  cuisine: string;
  rating: number;
  deliveryTime: string;
  image: string;
}

const restaurants: Restaurant[] = [
  {
    id: 1,
    name: "Bella Italia",
    cuisine: "Italian",
    rating: 4.8,
    deliveryTime: "25-35",
    image: "https://images.unsplash.com/photo-1516100882582-96c3a05fe590?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 2,
    name: "Sushi Master",
    cuisine: "Japanese",
    rating: 4.7,
    deliveryTime: "30-45",
    image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 3,
    name: "Burger House",
    cuisine: "American",
    rating: 4.5,
    deliveryTime: "20-30",
    image: "https://images.unsplash.com/photo-1586816001966-79b736744398?auto=format&fit=crop&q=80&w=800"
  }
];

const categories = [
  { name: 'Pizza', icon: Pizza },
  { name: 'Burgers', icon: Sandwich },
  { name: 'Steaks', icon: Beef },
  { name: 'Mexican', icon: Utensils },
  { name: 'Coffee', icon: Coffee },
  { name: 'Desserts', icon: IceCream },
];

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('Home');

  const navigationItems = [
    { icon: Home, label: 'Home' },
    { icon: Search, label: 'Search' },
    { icon: ShoppingBag, label: 'Orders' },
    { icon: User, label: 'Profile' }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'Home':
        return (
          <>
            {/* Categories */}
            <section className="mb-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Categories</h2>
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-4">
                {categories.map((category) => (
                  <button
                    key={category.name}
                    className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-shadow duration-200 flex flex-col items-center"
                  >
                    <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-2">
                      <category.icon className="h-6 w-6 text-orange-500" />
                    </div>
                    <span className="text-sm font-medium text-gray-700">{category.name}</span>
                  </button>
                ))}
              </div>
            </section>

            {/* Featured Restaurants */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Featured Restaurants</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {restaurants.map((restaurant) => (
                  <div key={restaurant.id} className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-200">
                    <img
                      src={restaurant.image}
                      alt={restaurant.name}
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-4">
                      <h3 className="text-lg font-semibold text-gray-900">{restaurant.name}</h3>
                      <p className="text-sm text-gray-500">{restaurant.cuisine}</p>
                      <div className="mt-2 flex items-center justify-between">
                        <div className="flex items-center">
                          <Star className="h-5 w-5 text-yellow-400 fill-current" />
                          <span className="ml-1 text-sm font-medium text-gray-700">{restaurant.rating}</span>
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Clock className="h-4 w-4 mr-1" />
                          <span>{restaurant.deliveryTime} min</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </>
        );
      case 'Search':
        return (
          <div className="p-4 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Search</h2>
            <p className="text-gray-600">Search for your favorite restaurants and dishes</p>
          </div>
        );
      case 'Orders':
        return (
          <div className="p-4 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Your Orders</h2>
            <p className="text-gray-600">Track your current orders and view order history</p>
          </div>
        );
      case 'Profile':
        return (
          <div className="p-4 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Profile</h2>
            <p className="text-gray-600">Manage your account settings and preferences</p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm fixed w-full z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center">
            <ShoppingBag className="h-8 w-8 text-orange-500" />
            <span className="ml-2 text-xl font-bold text-gray-900">YUMCART</span>
          </div>
          <div className="flex-1 max-w-lg mx-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search for restaurants or dishes"
                className="w-full pl-10 pr-4 py-2 rounded-full border border-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <button className="text-gray-600 hover:text-gray-900">
              <User className="h-6 w-6" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-20 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {renderContent()}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-around py-3">
            {navigationItems.map((item) => (
              <button
                key={item.label}
                className={`flex flex-col items-center space-y-1 ${
                  activeTab === item.label
                    ? 'text-orange-500'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
                onClick={() => setActiveTab(item.label)}
              >
                <item.icon className="h-6 w-6" />
                <span className="text-xs">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>
    </div>
  );
}

export default App;