package com.genpact.capstone_hms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneHmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
