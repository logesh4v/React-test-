package com.genpact.capstone_hms.model;

public class Login {
	private int id;
	private String username, password;
	private String domain;

	public Login()
	{}
	
	// compatible constructor for jsdbc rowMapper..
	public Login(int id, String username, String password) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
	}

	
	public Login(int id, String username, String password, String domain) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.domain = domain;
	}

	public Login(String username, String password, String domain) {
		super();
		this.username = username;
		this.password = password;
		this.domain = domain;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}

	@Override
	public String toString() {
		return "Login [id=" + id + ", username=" + username + ", password=" + password + ", domain=" + domain + "]";
	}
	
}
