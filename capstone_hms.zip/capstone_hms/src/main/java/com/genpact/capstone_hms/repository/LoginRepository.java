package com.genpact.capstone_hms.repository;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.genpact.capstone_hms.model.Login;

@Repository
public class LoginRepository {
    private String emsg;
	private JdbcTemplate jdbc;
    private RowMapper<Login> loginRowMapper = (resultSet, rowNums) -> 
        new Login(resultSet.getInt("id"), resultSet.getString("username"), resultSet.getString("password"));

    public LoginRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public String ifUsernameExist(String username, String domain) {
        if (!isValidDomain(domain)) {
            emsg = "Error: Login domain undefined!";
            return emsg;
        }
        String tableName = getTableName(domain);
        String sql = "SELECT username FROM " + tableName + " WHERE username = ?";
        try {
            Login result = jdbc.queryForObject(sql, loginRowMapper, username);
            emsg = "success";
            return result != null ? "true" : "false";
        } catch (DataAccessException e) {
            System.err.println("Database access error: " + e.getMessage());
            emsg = "Error accessing database";
            return emsg;
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
            emsg = "Unexpected error occurred: " + e.getMessage();
            return emsg;
        }
    }

    public String ifPasswordExist(String password, String domain) {
        if (!isValidDomain(domain)) {
            emsg = "Error: Login domain undefined!";
            return emsg;
        }
        String tableName = getTableName(domain);
        String sql = "SELECT password FROM " + tableName + " WHERE password = ?";
        try {
            Login result = jdbc.queryForObject(sql, loginRowMapper, password);
            emsg = "success";
            return result != null ? "true" : "false";
        } catch (DataAccessException e) {
            System.err.println("Database access error: " + e.getMessage());
            emsg = "Error accessing database: " + e.getMessage();
            return emsg;
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
            emsg = "Unexpected error occurred: " + e.getMessage();
            return emsg;
        }
    }

    private boolean isValidDomain(String domain) {
        return domain.equalsIgnoreCase("admin") || domain.equalsIgnoreCase("doctor") ||
               domain.equalsIgnoreCase("patient") || domain.equalsIgnoreCase("staff");
    }

    private String getTableName(String domain) {
        switch (domain.toLowerCase()) {
            case "admin":
                return "adminslogin";
            case "doctor":
                return "doctorslogin";
            case "patient":
                return "patientslogin";
            case "staff":
                return "stafflogin";
            default:
                return null;
        }
    }
    
    public String getEmsg() {
		return emsg;
	}

}
