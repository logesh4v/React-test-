package com.genpact.capstone_hms.model;

import java.sql.Date;
import java.sql.Timestamp;

public class BillingModel {
    private int billID;
    private int patientID;
    private double amount;
    private Date date;
    private String paymentStatus;
    private Timestamp billingTime;

    // Parameterized Constructor
    public BillingModel(int billID, int patientID, double amount, Date date, String paymentStatus, Timestamp billingTime) {
        this.billID = billID;
        this.patientID = patientID;
        this.amount = amount;
        this.date = date;
        this.paymentStatus = paymentStatus;
        this.billingTime = billingTime;
    }

    // Extra Parameterized Constructor without ID and Billing Time
    public BillingModel(int patientID, double amount, Date date, String paymentStatus) {
        this.patientID = patientID;
        this.amount = amount;
        this.date = date;
        this.paymentStatus = paymentStatus;
    }

    // Getters and Setters
    public int getBillID() {
        return billID;
    }

    public void setBillID(int billID) {
        this.billID = billID;
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public Timestamp getBillingTime() {
        return billingTime;
    }

    public void setBillingTime(Timestamp billingTime) {
        this.billingTime = billingTime;
    }

    // toString Method
    @Override
    public String toString() {
        return "BillingModel{" +
                "billID=" + billID +
                ", patientID=" + patientID +
                ", amount=" + amount +
                ", date=" + date +
                ", paymentStatus='" + paymentStatus + '\'' +
                ", billingTime=" + billingTime +
                '}';
    }
}
